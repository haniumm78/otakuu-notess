OTAKU NOTES WEBSITE

1. Extract this folder somewhere permanent, for example Desktop.
2. Open the Otaku_Notes_Website folder.
3. Double-click index.html to open the website in Chrome or Edge.
4. To edit the code, right-click index.html > Open with > Notepad.

NOTE:
- Keep index.html in this folder; do not run it from a temporary RAR/ZIP preview folder.
- This is a local website file. To share a clickable public link with friends, publish it using GitHub Pages.
- Any remote image placeholders or online resources need an internet connection.
